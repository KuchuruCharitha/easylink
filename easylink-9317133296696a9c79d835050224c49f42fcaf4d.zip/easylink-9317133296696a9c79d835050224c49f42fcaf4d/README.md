signup page:
![](results/sigup%20page.png)

sigin page:
![](results/signin%20page.png)
`
create channel:
![](results/create%20channel.png)

create and invite to channel:
![](results/create%20and%20invite%20channel.png)

direct message:
![](results/direct%20message.png)

options:
![](results/options.png)

reactions:
![](results/reactions.png)

search channel:
![](results/search%20channel.png)

thread reply:
![](results/thread%20reply.png)